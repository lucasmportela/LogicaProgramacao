# Questão 3 — Programação Orientada a Objetos: Gestão de Acervo (3.py) [Valor: 20
# Pontos]
# Para modernizar a biblioteca corporativa, foi solicitada a criação da classe base de gerenciamento de livros
# do acervo utilizando os conceitos fundamentais de Orientação a Objetos em Python, sem herança.
# ● Regras de Negócio e Requisitos da Classe Livro:
# ○ Atributos de Instância: No construtor (__init__), inicialize: titulo (str), autor (str),
# ano_publicacao (int) e disponivel (bool, padrão True).
# ○ Métodos da Classe: Implementar os seguintes métodos com validação do estado do
# objeto:
# i. emprestar(): se disponível, altera para False e emite sucesso; se já emprestado,
# emite aviso de indisponibilidade;
# ii. devolver(): se emprestado, altera para True e confirma devolução; se já disponível,
# avisa que não constava como emprestado;
# iii. exibir_ficha_tecnica(): imprime de forma organizada os dados do exemplar (Título,
# Autor, Ano e Situação: 'Disponível' ou 'Emprestado').
# ○ Bateria de Testes:
# i. instanciar pelo menos 2 livros distintos e executar a sequência:
# # ii. exibição das fichas iniciais;
# iii. empréstimo do livro 1;
# iv. tentativa de novo empréstimo do livro 1 (validando a trava);
# v. devolução do livro 1;
# vi. exibição das fichas finais atualizadas.
# Restrição Técnica: Proibido o uso de herança neste momento. Manter a consistência do atributo
# self.disponivel através dos métodos.
class Livro:
    def __init__(self, titulo, autor, ano_publicacao, disponivel = True):
        self.titulo = titulo
        self.autor = autor
        self.ano_publicacao = ano_publicacao
        self.disponivel = disponivel
    def emprestar(self): #cria a função emprestar
        if self.disponivel: #checa se está disponível
            self.disponivel = False #altera pra indisponível
            print("Emprestado!")
        else: #não empresta pq está indisponível
            print("Indisponível!")
    def devolver(self): #cria a função devolver
        if not self.emprestar: #checa se não está emprestado
            self.disponivel = True #altera para disponível
            print("Indisponível!")
        else: 
            print("Disponível")
    def exibir_ficha_tecnica(self):
        if self.disponivel: #se disponível muda a situação para disponível
            situacao = "Disponível"
        else: #se indosponível altera a situação para indisponível
            situacao = "Indisponível"
        print(f"Titulo: {self.titulo}")
        print(f"Autor: {self.autor} ")
        print(f"Ano: {self.ano_publicacao}")
        print(f"Situação: {self.disponivel}")
livro1 = Livro("Introdução a python","Lucas Martins","2026")
livro2 = Livro("Introdução a Flask", "Ana Carolina","2002") 
livro1.exibir_ficha_tecnica()
livro2.exibir_ficha_tecnica()
livro1.emprestar()
livro1.emprestar()
livro1.devolver()
