# Questão 1 — Auditoria de Faturamento e Descontos via CSV (1.py) [Valor: 20 Pontos]
# A divisão de vendas precisa automatizar a apuração de pedidos comerciais. Construa um programa em
# Python que realize a leitura do arquivo estruturado pedidos.csv (campos delimitados por ponto e vírgula
# ';'), aplique as regras de faturamento e exiba um relatório no console.
# ● Exemplo de pedidos.csv (arquivo de entrada fornecido):
# id_pedido;cliente;produto;quantidade;preco_unitario
# 101;Oficina Alfa;Teclado Mecanico;4;150.00
# 102;Metalurgica Beta;Monitor 27;12;85.50
# 103;AutoPecas Gama;Mouse Pad Gamer;8;210.00
# 104;Logistica Delta;Cabo HDMI;15;45.00
# 105;Mecanica Epsilon;Headset Sem Fio;3;320.00
# ● Regras de Negócio e Requisitos Técnicos:
# a) Tratamento de Arquivo: Abrir o arquivo utilizando tratamento de erros (try / except
# FileNotFoundError), exibindo mensagem amigável caso não seja localizado.
# b) Valor Bruto: Para cada pedido, calcular Valor Bruto = quantidade * preco_unitario.
# c) Desconto Progressivo: Se quantidade >= 10, aplicar 10% de desconto sobre o bruto; se entre
# 6 e 9 (inclusive), aplicar 5% de desconto; se menos de 6, desconto de 0.00.
# d) Valor Líquido e Status: Calcular Valor Líquido = Valor Bruto - Desconto. Se valor líquido >=
# 1000.00, classificar como 'PREMIUM', senão 'PADRÃO'.
# e) Relatório Consolidado: Exibir listagem tabular dos pedidos (ID, Cliente, Bruto, Desconto e
# Líquido em 2 casas decimais) e, ao final, Faturamento Bruto Total, Total de Descontos,
# Faturamento Líquido Total e dados do maior pedido líquido.
# Restrição Técnica: Proibido o uso de bibliotecas de terceiros (como pandas). Utilizar laço explícito
# para varredura e acumulação manual.
import csv
from decimal import Decimal
try:
    with open("pedidos.csv", "r", encoding="utf-8", newline="") as arquivo: #abre o arquivo csv
        leitor = csv.DictReader(arquivo, delimiter=";")
        total_bruto = Decimal("0.00")
        total_descontos = Decimal("0.00")
        total_liquido = Decimal("0.00")
        maior_valor_liquido = None
        maior_id = ""
        maior_cliente = ""
        maior_produto = ""
        maior_status = ""
        print(f"{'ID':<8} {'Cliente':<22} {'Bruto':>12} {'Desconto':>12} {'Líquido':>12} {'Status':<8}")
        for linha in leitor: #Lê cada linha do arquivo
            id_pedido = linha["id_pedido"]
            cliente = linha["cliente"]
            produto = linha["produto"]
            quantidade = int(linha["quantidade"])
            preco_unitario = Decimal(linha["preco_unitario"])
            valor_bruto = quantidade * preco_unitario
            if quantidade >= 10: #se quantidade maior ou igual a 10 aplica desconto de 10%
                desconto = valor_bruto * Decimal("0.10")
            elif quantidade >= 6: #se quantidade maior ou igual a 6 aplica desconto de 5%
                desconto = valor_bruto * Decimal("0.05")
            else: #se não nenhum desconto é aplicado
                desconto = Decimal("0.00")
            valor_liquido = valor_bruto - desconto #aplica os descontos no valor
            if valor_liquido >= Decimal("1000.00"): #verifica a classificação se for maior ou igual a 1000 status vira premium
                status = "PREMIUM"
            else: #se não status vira padrão
                status = "PADRÃO"
            total_bruto += valor_bruto
            total_descontos += desconto
            total_liquido += valor_liquido
            if maior_valor_liquido is None or valor_liquido > maior_valor_liquido: #faz a verificação para  o maior pedido
                maior_valor_liquido = valor_liquido
                maior_id = id_pedido
                maior_cliente = cliente
                maior_produto = produto
                maior_status = status
        print(f"{id_pedido:<8} {cliente:<22} {valor_bruto:>12.2f} {desconto:>12.2f} {valor_liquido:>12.2f} {status:<8}")
        print(f"Faturamento Bruto Total: R$ {total_bruto:.2f}")
        print(f"Total de Descontos: R$ {total_descontos:.2f}")
        print(f"Faturamento Líquido Total: R$ {total_liquido:.2f}")
        if maior_valor_liquido is not None: #retorna o print caso o maior líguido n for nulo
            print(f"ID: {maior_id}")
            print(f"Cliente: {maior_cliente}")
            print(f"Produto: {maior_produto}")
            print(f"Valor Líquido: R$ {maior_valor_liquido:.2f}")
            print(f"Status: {maior_status}")
        else: #retorna mensagem caso nenhum pedido for encontrado
            print("Nenhum pedido encontrado no arquivo.")
except FileNotFoundError: # retorna mensagem de erro caso nenhum arquivo for encontrado
    print("Erro: arquivo pedidos.csv não encontrado!")
    print("Verifique se o arquivo está na mesma pasta do programa.")