# Questão 2 — Sistema de Gestão de Chamados Técnicos (Service Desk) (2.py) [Valor: 20
# Pontos]
# A central de suporte de TI necessita de um módulo de console para registro, triagem e controle de
# chamados técnicos internos. Desenvolva uma solução estruturada em Python utilizando modularização
# com funções, listas e dicionários.
# ● Regras de Negócio e Requisitos Técnicos:
# a. Estrutura de Dados: Armazenar chamados em lista de dicionários com chaves: id (inteiro
# incremental a partir de 1), usuario (texto), descricao (texto), prioridade ('BAIXA', 'MEDIA'
# ou 'ALTA') e status (iniciado automaticamente como 'ABERTO').
# b. Validação com while: A prioridade deve ser validada via laço while, aceitando apenas
# 'BAIXA', 'MEDIA' ou 'ALTA', solicitando redigitação imediata em caso de erro.
# c. Funções Obrigatórias: Implementar obrigatoriamente as seguintes funções estruturadas:
# i. adicionar_chamado(lista, id, usuario, descricao, prioridade): recebe os dados,
# monta o dicionário e insere na lista;
# ii. listar_chamados(lista, filtro_prioridade=None): percorre e imprime os chamados
# (com filtro opcional de prioridade ou todos caso None);
# iii. encerrar_chamado(lista, id): localiza pelo ID e altera status para 'CONCLUÍDO' (ou
# avisa caso não exista);
# iv. obter_total_abertos(lista): retorna a quantidade total de chamados ainda com
# status 'ABERTO'.
# d. Menu de Console: Construir menu interativo em console com laço contínuo: 1 - Novo
# Chamado, 2 - Listar Todos, 3 - Listar por Prioridade, 4 - Encerrar Chamado e 0 - Sair.
# Restrição Técnica: Funções com parâmetros e retornos bem definidos. Lógica de busca e
# acumulação via laços for e condicionais if.
# Lista que armazenará todos os chamados
chamados = []
def solicitar_prioridade():
    prioridade = input("Digite a prioridade (BAIXA, MEDIA ou ALTA): ").strip().upper() #define o valor de prioridade
    while prioridade not in ["BAIXA", "MEDIA", "ALTA"]: #verifica se o valor de prioridade não é uma das opções disponíveis
        print("Prioridade inválida! Tente novamente.") #printa que prioridade n é aceitavel
        prioridade = input("Digite a prioridade: (BAIXA/MEDIA/ALTA) ").strip().upper() #lê novamente o valor de prioridade
    return prioridade #retorna o valor de prioridade certo
def adicionar_chamado(lista, id, usuario, descricao, prioridade): #cria a função adicionar_chamado
    chamado = {"id": id, "usuario": usuario, "descricao": descricao,"prioridade": prioridade, "status": "ABERTO"} #atribui os valores de chamado
    lista.append(chamado) #coloca o chomado na lista
    print("Sucesso!") #printa o sucesso de criação do chamado
    return chamado #retorna o chamado
def listar_chamados(lista, filtro_prioridade=None): #função de listar os chamados
    encontrou = False #seta o encontrou para falso por padrão
    for chamado in lista:
        if filtro_prioridade is None or chamado["prioridade"] == filtro_prioridade: #verifica o filho de prioridade
            print(f"ID: {chamado['id']}")
            print(f"Usuário: {chamado['usuario']}")
            print(f"Descrição: {chamado['descricao']}")
            print(f"Prioridade: {chamado['prioridade']}")
            print(f"Status: {chamado['status']}")
            encontrou = True #seta o encontrou para true
    if not encontrou: #verificar se não encontrouu
        print("Chamado não encontrado!") #printa que o chamado não foi encontrado
def encerrar_chamado(lista, id): #função encerar chamado
        for chamado in lista: #percorre cada linha do chamado
            if chamado["id"] == id: #verifica o valor de id do chamado
                chamado["status"] = "CONCLUÍDO" #seta o status como concluido
                print("Chamado encontrado!") #printa que o chamado foi encontrado
                return True #retorna true
            print("Chamado não encontrado!")
            return False #retorna false
def obter_total_abertos(lista): #função de verificar o total de abertos
    total = 0
    for chamado in lista: #percorre cada linha de chamado
        if chamado["status"] == "ABERTO": #verifica se chamado está aberto
            total += 1 #somador
    return total #retorna total
def main():
    proximo_id = 1
    while True: #enquanto for verdadeiro printa
        print("1 | Novo Chamado")
        print("2 | Listar Todos")
        print("3 | Listar por Prioridade")
        print("4 | Encerrar Chamado")
        print("0 | Sair")
        opcao = input("Escolha uma opção: ") #input
        if opcao == "1":
            usuario = input("Usuário: ")
            descricao = input("Descrição: ")
            prioridade = solicitar_prioridade()
            adicionar_chamado(chamados,proximo_id,usuario,descricao,prioridade)
            proximo_id += 1
        elif opcao == "2":
            listar_chamados(chamados)
            print(f"Total de chamados abertos: {obter_total_abertos(chamados)}")
        elif opcao == "3":
            prioridade = solicitar_prioridade()
            listar_chamados(chamados, prioridade)
        elif opcao == "4":
            try:
                id_chamado = int(input("Informe ID do chamado: "))
                encerrar_chamado(chamados, id_chamado)
                print(f"Total de chamados abertos: {obter_total_abertos(chamados)}")
            except ValueError:
                print("Erro: informe um ID numérico!")
        elif opcao == "0":
            print("Encerrando o sistema!")
            break
        else:
            print("Opção inválida!")
if __name__ == "__main__":
    main()